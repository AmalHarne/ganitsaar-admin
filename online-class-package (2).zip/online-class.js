// online-class.js
// Ganitsar: online classes, online tests and study material. No Google sign-in.
//
// Install:  npm i express express-session better-sqlite3
// Secrets (Replit -> Secrets):
//   SESSION_SECRET   any long random text
//   ADMIN_PASSCODE   the secret passcode only YOU know (opens admin.html). Without it the admin site stays locked.
//   JOIN_CODE        optional, default 0770 (students type it to see the class meeting link)
//
// Use in your main server file, right after `const app = express();`:
//   require('./online-class')(app);
//
// Two websites, one server:
//   /classes.html  student site (everyone: tests, study material, class schedule)
//   /admin.html    admin site (passcode; create classes, tests, study material; see results)
//
// Rules enforced HERE on the server (not just hidden in the page):
//   - The meeting link is shown only after the student types the join code.
//   - Test answers are graded on the server and never sent to the browser before submission.
//   - Only a visitor who entered ADMIN_PASSCODE can create or delete classes, tests and
//     study material, or see test results.

const express = require('express');
const session = require('express-session');
const Database = require('better-sqlite3');
const crypto = require('crypto');

const ADMIN_EMAIL = '1molharne@gmail.com';
// Code students type to join an online class (change it in Replit Secrets as JOIN_CODE).
const JOIN_CODE = String(process.env.JOIN_CODE || '0770');
const MAX_PHOTO_CHARS = 3 * 1000 * 1000; // data URL length cap (about 2 MB image)

module.exports = function setupOnlineClass(app) {
  // ---------- database ----------
  const db = new Database(process.env.DB_FILE || 'classes.db');
  db.pragma('journal_mode = WAL');
  db.pragma('synchronous = NORMAL');
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY, name TEXT, email TEXT UNIQUE, photo TEXT, role TEXT DEFAULT 'student'
    );
    CREATE TABLE IF NOT EXISTS classes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      standard INTEGER,
      topic TEXT,
      description TEXT,
      start_at TEXT NOT NULL,
      duration_min INTEGER DEFAULT 60,
      meeting_link TEXT,
      created_by TEXT,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE INDEX IF NOT EXISTS idx_classes_start ON classes(start_at);
    CREATE TABLE IF NOT EXISTS tests (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      standard INTEGER NOT NULL,
      ch INTEGER,
      duration_min INTEGER NOT NULL,
      question_count INTEGER NOT NULL,
      questions TEXT NOT NULL,            -- JSON: [{q, opts:[4], a}]
      created_by TEXT,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS attempts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      test_id INTEGER NOT NULL,
      user_id TEXT NOT NULL,
      started_at TEXT NOT NULL,
      submitted_at TEXT,
      score INTEGER,
      total INTEGER,
      answers TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_attempts_user ON attempts(user_id, test_id);
    CREATE TABLE IF NOT EXISTS materials (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      standard INTEGER NOT NULL,
      ch INTEGER,
      notes TEXT,
      link TEXT,
      photo TEXT,
      medium TEXT,                        -- 'en' (English medium), 'mr' (Marathi medium) or NULL
      created_by TEXT,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
  `);
  // Older installs of this module had no chapter column on classes.
  try { db.exec('ALTER TABLE classes ADD COLUMN ch INTEGER'); } catch (_) { /* already there */ }
  try { db.exec('ALTER TABLE materials ADD COLUMN medium TEXT'); } catch (_) { /* already there */ }

  const q = {
    dropOtherUserWithEmail: db.prepare('DELETE FROM users WHERE email = ? AND id != ?'),
    upsertUser: db.prepare(
      `INSERT INTO users (id, name, email, photo, role) VALUES (?, ?, ?, ?, ?)
       ON CONFLICT(id) DO UPDATE SET name=excluded.name, email=excluded.email,
         photo=excluded.photo, role=excluded.role`
    ),
    listClasses: db.prepare('SELECT * FROM classes WHERE start_at >= ? ORDER BY start_at ASC LIMIT 200'),
    getClass: db.prepare('SELECT * FROM classes WHERE id = ?'),
    insertClass: db.prepare(
      `INSERT INTO classes (title, standard, topic, ch, description, start_at, duration_min, meeting_link, created_by)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ),
    deleteClass: db.prepare('DELETE FROM classes WHERE id = ?'),

    listTests: db.prepare(
      'SELECT id, title, standard, ch, duration_min, question_count FROM tests ORDER BY standard, ch, id'
    ),
    getTest: db.prepare('SELECT * FROM tests WHERE id = ?'),
    insertTest: db.prepare(
      `INSERT INTO tests (title, standard, ch, duration_min, question_count, questions, created_by)
       VALUES (?, ?, ?, ?, ?, ?, ?)`
    ),
    deleteTest: db.prepare('DELETE FROM tests WHERE id = ?'),
    deleteTestAttempts: db.prepare('DELETE FROM attempts WHERE test_id = ?'),
    lastScores: db.prepare(
      `SELECT test_id, score, total FROM attempts
       WHERE user_id = ? AND submitted_at IS NOT NULL ORDER BY id ASC`
    ),
    insertAttempt: db.prepare('INSERT INTO attempts (test_id, user_id, started_at) VALUES (?, ?, ?)'),
    getAttempt: db.prepare('SELECT * FROM attempts WHERE id = ?'),
    finishAttempt: db.prepare(
      'UPDATE attempts SET submitted_at = ?, score = ?, total = ?, answers = ? WHERE id = ? AND submitted_at IS NULL'
    ),
    results: db.prepare(
      `SELECT a.id, a.score, a.total, a.submitted_at, u.name, u.email
       FROM attempts a JOIN users u ON u.id = a.user_id
       WHERE a.test_id = ? AND a.submitted_at IS NOT NULL ORDER BY a.id DESC LIMIT 500`
    ),

    listMaterials: db.prepare('SELECT * FROM materials ORDER BY standard, ch, id'),
    insertMaterial: db.prepare(
      `INSERT INTO materials (title, standard, ch, notes, link, photo, medium, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    ),
    getMaterial: db.prepare('SELECT * FROM materials WHERE id = ?'),
    deleteMaterial: db.prepare('DELETE FROM materials WHERE id = ?'),
  };

  // ---------- built-in tests ----------
  // class5-tests.json: 16 tests (Class 5, one per chapter, English). class6-tests.json: 19 tests
  // (Class 6, one per chapter, Marathi + English). 20 questions each.
  // They are part of the website itself: always present, and they cannot be deleted.
  // The admin can still create extra tests when needed; those are stored in the database.
  const BUILTIN_BASE = 1000000;
  let builtinSeed = [];
  // Order matters: ids are BUILTIN_BASE + position, so new files are only ever appended.
  // Each file owns a block of 1000 ids, so a missing file never shifts the ids of the others.
  ['./class5-tests.json', './class6-tests.json', './class7-tests.json', './class8-tests.json',
   './class9-tests.json', './class10-tests.json'].forEach((f, k) => {
    try { require(f).forEach((t, i) => builtinSeed.push({ ...t, _id: k * 1000 + i })); } catch (_) { /* file not present */ }
  });
  // A text can be a plain string or { mr, en }; pick the reader's language.
  const loc = (v, lang) => (v && typeof v === 'object' && !Array.isArray(v) ? (v[lang] || v.en || v.mr || '') : v);
  const langOf = (v) => (v === 'mr' ? 'mr' : 'en');
  const BUILTIN = builtinSeed.map((s, i) => ({
    id: BUILTIN_BASE + s._id, title: s.title, standard: s.standard, ch: s.ch, duration_min: s.durationMin,
    question_count: s.qs.length, questions: JSON.stringify(s.qs), builtin: true,
  }));
  const builtinById = new Map(BUILTIN.map((t) => [t.id, t]));
  const findTest = (id) => builtinById.get(id) || q.getTest.get(id);

  // ---------- middleware ----------
  try { app.use(require('compression')()); } catch (_) { /* optional: npm i compression */ }
  app.set('trust proxy', 1);
  app.use(express.json({ limit: '4mb' }));
  app.use(
    session({
      secret: process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex'),
      resave: false,
      saveUninitialized: false,
      cookie: { httpOnly: true, sameSite: 'lax', secure: 'auto', maxAge: 1000 * 60 * 60 * 24 * 14 },
    })
  );
  // Every visitor is a student with an anonymous identity kept in the session cookie.
  // The admin is whoever entered ADMIN_PASSCODE (decided on the server only).
  const ADMIN_PASSCODE = String(process.env.ADMIN_PASSCODE || '');
  const sameSecret = (a, b) => {
    const x = Buffer.from(String(a)), y = Buffer.from(String(b));
    return x.length === y.length && crypto.timingSafeEqual(x, y);
  };
  app.use((req, res, next) => {
    const sess = req.session;
    if (!sess) return next();
    if (sess.admin === true) {
      req.user = { id: 'admin', name: 'Admin', email: ADMIN_EMAIL, photo: null, role: 'admin' };
    } else {
      if (!sess.gid) sess.gid = 'g' + crypto.randomBytes(9).toString('hex');
      req.user = { id: sess.gid, name: 'Student', email: sess.gid + '@guest.local', photo: null, role: 'student' };
    }
    // keep a users row so scores and results can be joined
    try { q.upsertUser.run(req.user.id, req.user.name, req.user.email, null, req.user.role); } catch (_) { /* ignore */ }
    next();
  });

  const requireLogin = (req, res, next) => next();   // everyone may take tests
  const requireAdmin = (req, res, next) => {
    if (!req.user || req.user.role !== 'admin') return res.status(403).json({ error: 'Admin only. Open the admin site and enter the admin passcode.' });
    next();
  };

  // ---------- small validators ----------
  const clip = (s, n) => String(s == null ? '' : s).trim().slice(0, n);
  const stdOf = (v) => { const n = parseInt(v, 10); return n >= 5 && n <= 10 ? n : null; };
  const chOf = (v) => { const n = parseInt(v, 10); return Number.isInteger(n) && n >= 0 && n < 100 ? n : null; };
  // Classes that are split into chapters, and how many chapters each has.
  const CHAPTER_COUNT = { 5: 16, 6: 19, 7: 15, 8: 17, 9: 16, 10: 13 };
  const chFor = (std, v) => {
    const n = chOf(v);
    return CHAPTER_COUNT[std] && n !== null && n < CHAPTER_COUNT[std] ? n : null;
  };
  const isHttpUrl = (s) => {
    try { const u = new URL(s); return u.protocol === 'https:' || u.protocol === 'http:'; } catch { return false; }
  };
  const toDate = (date, time) => {
    const d = new Date(`${date}T${time}:00+05:30`);
    return isNaN(d) ? null : d;
  };

  // ---------- admin passcode ----------
  app.post('/auth/admin', (req, res) => {
    const sess = req.session;
    const now = Date.now();
    if (!ADMIN_PASSCODE) return res.status(503).json({ error: 'Admin is locked: add the ADMIN_PASSCODE secret in Replit, then Stop and Run.' });
    if (sess.adminLockUntil && sess.adminLockUntil > now) return res.status(429).json({ error: 'Too many wrong tries. Try again in a few minutes.' });
    if (!sameSecret((req.body && req.body.passcode) || '', ADMIN_PASSCODE)) {
      sess.adminFails = (sess.adminFails || 0) + 1;
      if (sess.adminFails >= 5) { sess.adminLockUntil = now + 5 * 60 * 1000; sess.adminFails = 0; }
      return res.status(403).json({ error: 'Wrong passcode.' });
    }
    sess.admin = true; sess.adminFails = 0;
    res.json({ ok: true });
  });

  app.post('/auth/logout', (req, res) => {
    req.session.admin = false;
    res.json({ ok: true });
  });

  app.get('/api/me', (req, res) => {
    res.set('Cache-Control', 'no-store');
    const { id, name, role } = req.user;
    res.json({ user: { id, name, role }, joined: role === 'admin' || (req.session && req.session.joined === true), adminConfigured: !!ADMIN_PASSCODE });
  });

  // ---------- classes ----------
  // Anyone can see the schedule. The meeting link is only sent to signed-in users.
  app.get('/api/classes', (req, res) => {
    const cutoff = new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString();
    const rows = q.listClasses.all(cutoff);
    res.set('Cache-Control', 'no-store');
    // The meeting link is shown only after the class join code was entered (the admin always sees it).
    const canSee = !!req.user && (req.user.role === 'admin' || (req.session && req.session.joined === true));
    res.json(canSee ? rows : rows.map((c) => ({ ...c, meeting_link: null })));
  });

  // Student enters the join code once per session; wrong tries are limited.
  app.post('/api/classes/join', (req, res) => {
    const sess = req.session;
    const now = Date.now();
    if (sess.joinLockUntil && sess.joinLockUntil > now) {
      return res.status(429).json({ error: 'Too many wrong codes. Try again in a few minutes.' });
    }
    const given = Buffer.from(String((req.body && req.body.code) || '').trim());
    const want = Buffer.from(JOIN_CODE);
    const okCode = given.length === want.length && crypto.timingSafeEqual(given, want);
    if (!okCode) {
      sess.joinFails = (sess.joinFails || 0) + 1;
      if (sess.joinFails >= 5) { sess.joinLockUntil = now + 5 * 60 * 1000; sess.joinFails = 0; }
      return res.status(403).json({ error: 'Wrong join code.' });
    }
    sess.joined = true; sess.joinFails = 0;
    res.json({ ok: true });
  });

  app.post('/api/classes', requireAdmin, async (req, res) => {
    try {
      const b = req.body || {};
      const title = clip(b.title, 200);
      const std = stdOf(b.standard);
      const ch = chFor(std, b.ch);
      const topic = clip(b.topic, 200) || null;
      const description = clip(b.description, 2000) || null;
      const start = toDate(b.date, b.time);
      const dur = Math.min(Math.max(parseInt(b.durationMin, 10) || 60, 15), 300);

      if (!title) return res.status(400).json({ error: 'Title is required.' });
      if (!std) return res.status(400).json({ error: 'Choose a class from 5 to 10.' });
      if (!start) return res.status(400).json({ error: 'A valid date and time are required.' });

      let link = clip(b.meetingLink, 1000);
      if (!link || !isHttpUrl(link)) {
        return res.status(400).json({ error: 'Enter a valid meeting link .' });
      }
      const info = q.insertClass.run(title, std, topic, ch, description, start.toISOString(), dur, link, req.user.email);
      res.status(201).json(q.getClass.get(info.lastInsertRowid));
    } catch (e) {
      console.error(e);
      res.status(e.status || 500).json({ error: e.message });
    }
  });

  app.delete('/api/classes/:id', requireAdmin, (req, res) => {
    q.deleteClass.run(Number(req.params.id));
    res.json({ ok: true });
  });

  // ---------- online tests ----------
  // List: public (titles only). Includes the signed-in user's last score.
  app.get('/api/tests', (req, res) => {
    const last = new Map();
    if (req.user) for (const r of q.lastScores.all(req.user.id)) last.set(r.test_id, { score: r.score, total: r.total });
    res.set('Cache-Control', 'no-store');
    const lang = langOf(req.query.lang);
    const all = BUILTIN.map(({ questions, ...rest }) => ({ ...rest, title: loc(rest.title, lang) }))
      .concat(q.listTests.all().map((t) => ({ ...t, builtin: false })))
      .map((t) => ({ ...t, last_score: last.get(t.id) || null }));
    all.sort((x, y) => x.standard - y.standard || (x.ch == null ? -1 : x.ch) - (y.ch == null ? -1 : y.ch) ||
      (y.builtin ? 1 : 0) - (x.builtin ? 1 : 0) || x.id - y.id);
    res.json(all);
  });

  app.post('/api/tests', requireAdmin, (req, res) => {
    const b = req.body || {};
    const title = clip(b.title, 200);
    const std = stdOf(b.standard);
    const ch = chFor(std, b.ch);
    const dur = Math.min(Math.max(parseInt(b.durationMin, 10) || 10, 1), 180);
    if (!title) return res.status(400).json({ error: 'Title is required.' });
    if (!std) return res.status(400).json({ error: 'Choose a class from 5 to 10.' });
    if (CHAPTER_COUNT[std] && ch === null) return res.status(400).json({ error: `Choose a chapter for a Class ${std} test.` });
    if (!Array.isArray(b.qs) || b.qs.length < 1 || b.qs.length > 100) {
      return res.status(400).json({ error: 'A test needs 1 to 100 questions.' });
    }
    const qs = [];
    for (const item of b.qs) {
      const text = clip(item && item.q, 500);
      const opts = Array.isArray(item && item.opts) ? item.opts.map((o) => clip(o, 200)) : [];
      const a = parseInt(item && item.a, 10);
      if (!text || opts.length !== 4 || opts.some((o) => !o) || !(a >= 0 && a <= 3)) {
        return res.status(400).json({ error: 'Every question needs text, four options and one correct answer.' });
      }
      qs.push({ q: text, opts, a });
    }
    const info = q.insertTest.run(title, std, ch, dur, qs.length, JSON.stringify(qs), req.user.email);
    res.status(201).json({ id: Number(info.lastInsertRowid) });
  });

  app.delete('/api/tests/:id', requireAdmin, (req, res) => {
    const id = Number(req.params.id);
    if (builtinById.has(id)) return res.status(400).json({ error: 'Built-in tests cannot be deleted.' });
    q.deleteTestAttempts.run(id);
    q.deleteTest.run(id);
    res.json({ ok: true });
  });

  // Start: sign-in required. Sends questions WITHOUT the correct answers.
  app.post('/api/tests/:id/start', requireLogin, (req, res) => {
    const test = findTest(Number(req.params.id));
    if (!test) return res.status(404).json({ error: 'Test not found.' });
    const now = Date.now();
    const info = q.insertAttempt.run(test.id, req.user.id, new Date(now).toISOString());
    const lang = langOf((req.body || {}).lang);
    const questions = JSON.parse(test.questions).map(({ q: text, opts }) => ({
      q: loc(text, lang), opts: opts.map((o) => loc(o, lang)),
    }));
    res.json({
      attemptId: Number(info.lastInsertRowid),
      title: loc(test.title, lang),
      duration_min: test.duration_min,
      serverNow: now,
      endsAt: now + test.duration_min * 60000,
      questions,
    });
  });

  // Submit: sign-in required. Graded here; the time limit is checked here too.
  app.post('/api/tests/:id/submit', requireLogin, (req, res) => {
    const b = req.body || {};
    const att = q.getAttempt.get(Number(b.attemptId));
    if (!att || att.user_id !== req.user.id || att.test_id !== Number(req.params.id)) {
      return res.status(404).json({ error: 'Attempt not found.' });
    }
    if (att.submitted_at) return res.status(400).json({ error: 'This attempt was already submitted.' });
    const test = findTest(att.test_id);
    if (!test) return res.status(404).json({ error: 'Test not found.' });

    const deadline = Date.parse(att.started_at) + test.duration_min * 60000 + 60000; // 60 s grace
    if (Date.now() > deadline) return res.status(400).json({ error: 'Time is over for this attempt.' });

    const qs = JSON.parse(test.questions);
    const given = Array.isArray(b.answers) ? b.answers : [];
    const answers = qs.map((_, i) => {
      const n = Number(given[i]);
      return given[i] != null && Number.isInteger(n) && n >= 0 && n <= 3 ? n : null;
    });
    const score = qs.reduce((s, item, i) => s + (answers[i] === item.a ? 1 : 0), 0);
    q.finishAttempt.run(new Date().toISOString(), score, qs.length, JSON.stringify(answers), att.id);
    res.json({ score, total: qs.length, answers, correct: qs.map((item) => item.a) });
  });

  // Admin only: who took the test and their scores.
  app.get('/api/tests/:id/results', requireAdmin, (req, res) => {
    res.json(q.results.all(Number(req.params.id)));
  });

  // ---------- study material ----------
  app.get('/api/materials', (req, res) => {
    res.set('Cache-Control', 'no-store');
    res.json(q.listMaterials.all());
  });

  app.post('/api/materials', requireAdmin, (req, res) => {
    const b = req.body || {};
    const title = clip(b.title, 200);
    const std = stdOf(b.standard);
    const ch = chFor(std, b.ch);
    const notes = clip(b.notes, 5000) || null;
    const link = clip(b.link, 1000) || null;
    const photo = typeof b.photo === 'string' && b.photo ? b.photo : null;
    const medium = b.medium === 'en' || b.medium === 'mr' ? b.medium : null;

    if (!title) return res.status(400).json({ error: 'Title is required.' });
    if (!std) return res.status(400).json({ error: 'Choose a class from 5 to 10.' });
    if (link && !isHttpUrl(link)) return res.status(400).json({ error: 'The link must start with https://' });
    if (photo && (!/^data:image\/(png|jpeg|webp|gif);base64,[A-Za-z0-9+/=]+$/.test(photo) || photo.length > MAX_PHOTO_CHARS)) {
      return res.status(400).json({ error: 'The photo must be a PNG, JPEG, WebP or GIF under 2 MB.' });
    }
    if (!notes && !link && !photo) return res.status(400).json({ error: 'Add notes, a link or a photo.' });

    const info = q.insertMaterial.run(title, std, ch, notes, link, photo, medium, req.user.email);
    res.status(201).json(q.getMaterial.get(info.lastInsertRowid));
  });

  app.delete('/api/materials/:id', requireAdmin, (req, res) => {
    q.deleteMaterial.run(Number(req.params.id));
    res.json({ ok: true });
  });
};
